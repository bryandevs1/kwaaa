# Accordions-FAQ
create accordions using react and tailwind css (framer-motion)

## preview 
![image](https://user-images.githubusercontent.com/127585158/225286234-67ef2788-3154-4fb0-8328-c031ec531db6.png)
